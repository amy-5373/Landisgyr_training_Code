#include<stdio.h>
int addition ()
{
    int a,b;
    printf("enter two number:");
    scanf("%d %d",&a,&b);
    return a+b;
}
int sum(){
    return 20+30;
}
int fun1 (int a)
{
    return a;
}




int main()
{
 int result;
int (*ptr)();
 ptr=&addition;
// // ptr=&sum;
// ptr=&fun1;
result=(*ptr)();
printf("the sum is %d",result);


return 0;
}