#include<stdio.h>
struct structjob
{
 char name[32];
 float salary;
 int worknn;
 
 
 }sjob;
 
union unionjob
 {
 char name[32];
 float salary;
 int worknn;
 
 
 }ujob;
 
 int main()
 {
 ujob.salary=12.5;
  printf("salary=%0.1f\n",ujob.salary);
 ujob.worknn=100;
 printf("salary=%0.1f\n",ujob.salary);//  not print because it allocate the the same memory location, worknn will overwrite.
 printf("work no =%d\n",ujob.worknn);
 return 0;
 }
