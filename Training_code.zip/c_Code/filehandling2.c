#include<stdio.h>
int main()
{
    FILE *fp;
    
    fp=fopen("/home/madhu/cpp/text2.txt","w+");
    fprintf(fp,"this is testing for fprint...\n");
    fputs("this is testing for fputs...\n",fp);
    fclose(fp);
    return 0;
}