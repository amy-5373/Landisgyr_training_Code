#include<iostream>
using namespace std;


 template<class T>
 T sum (T a,T b)
 {
    T res;
    res= a+b;
    return res;
 }
  template<class T,class U>
  bool are_equal(T a, U b)
  {
    return (a==b);
  }
 int main()
 {
int x=2;int y=4;
double p =3.33; 
double q =5.6;
cout<< sum(x,y)<<endl;
cout<<sum(p,q)<<endl;

cout<<are_equal(2.2,5)<<endl;
return 0;
 }

