#include<stdio.h>
#include<stdlib.h>

// struct Node *temp=NULL;
// struct Node *front=NULL;
// struct Node *rear=NULL;
// struct Node *p;
//struct Node *rear=NULL;
//struct Node *head2=NULL;
struct Node
{
    int data;
    int priority;
     struct Node* next;
} * front=NULL,*rear=NULL;
// void initialize()
// {
//     front=NULL;
//     rear=NULL;
// }
// int isempty()
// {
//     if(front==NULL&&front==rear)
//         return 1;
        
//         return 0;
// }
void insert(int data,int priority){
struct Node *temp=(struct Node *)malloc(sizeof(struct Node));
if(temp==NULL)
{
    printf("memory isnot available");
    return;
}
temp->data=data;
temp->next=NULL;
temp->priority= priority;
if(front==NULL||front->priority>temp->priority)
{
    temp->next=front;
    front=temp;
}
else{
    struct Node *p=front;
    while(p->next!=NULL&& p->next->priority<=temp->priority)
     {
        p=p->next;
     }
     temp->next=p->next;
     p->next=temp;
}
rear=temp;


}
void delete()
{
    struct Node* temp=front;
    front=front->next;
    free(temp);
}
void isempty()
{
    if(front==NULL)
    printf("queue is empty");
    else
    printf("queue is noe empty");
}
void peek()
{
    if(front==NULL)
      printf("queue is empty");
      else
      printf("%d",front->data);
}
void print()
{
    struct Node *temp=front;
    while(temp!=NULL)
    {
        if(temp!=NULL)
        printf("%d",temp->data);
        else
         printf("%d",front->data);

         temp=temp->next;
    }
}



// void print()
// {
//     struct Node * curr= (struct Node*)malloc(sizeof(struct Node));
//     curr=front;
//     while(curr!=NULL)
//     {
//         printf("%d\t",curr->data);
//         curr=curr->next;
//     }
// // }
// int peek()
// {
//     if(isempty())
//     {
//         printf("queue underflow\n");
//         exit(1);
//     }
//     return front->data;
    
// }
// void delete()
// {
//     if(isempty())
//     {
//         printf("queue underflow\n");
//         exit(1);
//     }
//      struct Node * curr= (struct Node*)malloc(sizeof(struct Node));
//     curr=front;
//     front=front->next;
//     free(curr);
// }
int main()
{


 isempty();
 printf("\n");
 peek();
 printf("\n");
 insert(10,4);
 insert(20,2);
 insert(30,3);
 insert(40,5);
 insert(50,1);
 print();
 printf("\n");
 isempty();
 printf("\n");
 peek();
 delete();
 printf("\n");
 print();
return 0;



//   printf("%d\n",isempty());
//    printf("%d\n",peek());
// //    delete();

  


}