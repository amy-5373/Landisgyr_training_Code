#include<iostream>
using namespace std;
 namespace addition{
    int operation(int x,int y){return x+y;}

 }
 namespace substraction{
  
      int operation(int x,int y){return x-y;}
 }
 namespace multiplication{
      int operation(int x,int y){return x*y;}
 }
 namespace division{
      int operation(int x,int y){return x/y;}
 }
 int main()
 {
   int x,y;
   cin>>x>>y;
   cout<<addition::operation(x,y)<<endl;
     cout<<substraction::operation(x,y)<<endl;
       cout<<multiplication::operation(x,y)<<endl;
         cout<<division::operation(x,y)<<endl;
         return 0;
 }
