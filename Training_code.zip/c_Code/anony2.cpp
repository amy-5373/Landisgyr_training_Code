#include<iostream>
using namespace std;

typedef class{
    int a;
    public:
    void setData(int i)
    {
      this->a=i;
    }
    void printValues(){
        cout<<"values :"<<this->a<<endl;
    }
}myclass;
int main()
{
    myclass obj1,obj2;
    obj1.setData(10);
    obj1.printValues();

    obj2.setData(20);
    obj2.printValues();
    return 0;


}