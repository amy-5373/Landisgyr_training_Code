
#include<iostream>
using namespace std;
typedef unsigned char BYTE
void f()
    {
        char ch;
        int i=65;
        float f1=2.5;
        double dbl;
        ch = static_cast<char>(i);
        dbl= static_cast<double>(f1);
        // i=static_cast<BYTE>(ch);
        cout<<"hr";

    }


int main()
{
    f();
    return 0;
}
