#include<stdio.h>



int main()
{
    int *ptr=NULL;
printf("the value of ptr is :%x",ptr);//
return 0;
}