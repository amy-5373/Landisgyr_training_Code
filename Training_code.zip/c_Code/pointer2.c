#include<stdio.h>



int main()
{
    int x=10;
    printf("address of x: %p", &x);
return 0;
}