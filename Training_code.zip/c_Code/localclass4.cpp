#include<iostream>
using namespace std;
 void fun()
 {
    class Test //local to fun
    {
        public:
        void method()// fine method is defined inside the local class.
        {
            cout<<"local method called"<<endl;
        }
    };
    Test t;
    t.method();

 }
 int main()
 {
    fun();
    return 0;
 }