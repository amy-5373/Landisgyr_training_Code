#include<iostream>
using namespace std;

class student
{
    
    char name[30];

    public:
    int roll;
    student(int b)
    {    roll=b;
         //roll++;
         cout<<roll<<endl;
        cout<<" default constructor called--->";
    }


};
int main()
{
     const student a(5);
     a.roll++;
    return 0;

}