#include<stdio.h>
//#define area_t
#define circle_t

int main()
{

#ifdef area_t
printf("area_t is running");
#endif
#ifdef circle_t
printf("circle_t is running");
#endif
return 0;
}
