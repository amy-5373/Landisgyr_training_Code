




#include<iostream>
using namespace std;

class A{
    friend class B;
    friend class C;
    int a;

};
class B{
    friend class C;

};
class C:public B{
    void f(A*p){
    // following is error
    p->a=2;
    cout<<" this is f function"<<endl;
    }
};
int main()
{
    
    return 0;
}