#include<iostream>
// #include<vector.h>
#include<bits/stdc++.h>

using namespace std;
int main()
{    int v1[3],v2[3],v3[3][3];
    
    for(int i=0;i<3;i++)
    {
        cin>>v1[i];
    }
     for(int i=0;i<3;i++)
    {
        cin>>v2[i];
    }
    //int a= v2.size();
    //vector<vector<int>>v3;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            v3[i][j]= v2[i]*v1[j];
        }
    }
    printf("multiplication--->\n");
    for(int i= 0;i<3;i++)
    {
        for (int j=0;j<3;j++)
        {
            cout<<v3[i][j]<<" ";
        }
        printf("\n");
    }

      for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            v3[i][j]= v2[i]+v1[j];
        }
    }
     printf("addition--->\n");
    for(int i= 0;i<3;i++)
    {
        for (int j=0;j<3;j++)
        {
            cout<<v3[i][j]<<" ";
        }
        printf("\n");
    }

      for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            v3[i][j]= v2[i]-v1[j];
        }
    }
     printf("substraction-->\n");
    for(int i= 0;i<3;i++)
    {
        for (int j=0;j<3;j++)
        {
            cout<<v3[i][j]<<" ";
        }
        printf("\n");
    }
    return 0;

}