#include <iostream>
#include<conio.h>
#include<string.h>
#include <stdlib.h>

using namespace std;

struct userdetails{
    int accountnumber;
    char name[50];
    char password[50];
    int balance;
    int accounttype;
    userdetails *next;
}*head=NULL,*last=NULL;


class Account{
	public:
	void displayuser(){
        system("cls");
        cout<<"Account number: "<<last->accountnumber<<endl;
        cout<<"Account holder: "<<last->name<<endl;
        if (last->accounttype==1)
        cout<<"Account type: Current Account"<<endl;
        else
        cout<<"Account type: Savings Account"<<endl;
        cout<<"Account balance available: "<<last->balance<<"\n\n";
        cout<<"Account created successfully. Please note down these details.\n\n";
        hold();
    }

	Account(){
	 struct userdetails *temp=(struct userdetails *)malloc(sizeof(struct userdetails));
        system("cls");
        temp->next=NULL;
        cout<<"Enter 1 to open current account.\nEnter 2 to open savings(default) account.\n";
        int temptype;
        temptype=getch();
        if(temptype=='1')
        temp->accounttype=1;
        else
        temp->accounttype=2;
        cout<<"Enter your name: ";
        cin>>ws;
        // cin>>temp->name;
        scanf("%[^\t\n]",temp->name);
        cout<<"Enter a secret PIN: ";
        cin>>temp->password;
        cout<<"Enter amount to deposit: ";
        cin>>temp->balance;
        cout<<endl;
        // struct userdetails *headt=head;
        // for(int i=0;i<strlen(cname);i++)
        // temp->name[i]=cname[i];
        // for(int i=0;i<strlen(cpassword);i++)
        // temp->password[i]=cpassword[i];
        // temp->balance=cbalance;
        if(last){
            temp->accountnumber=last->accountnumber+1;
            last->next=temp;
            last=temp;
        }
        else{
            temp->accountnumber=1;
            head=temp;
            last=temp;
        }
        caccount_number=last->accountnumber;
        displayuser();
    
};
