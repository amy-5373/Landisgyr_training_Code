#include<iostream>
using namespace std;
 class Rectangle
 { 
    int x;
    int y;
    // int area;
    public:
    int area;
    int point;
     Rectangle()
 {
    point=30;
 }

  Rectangle(int a, int b)
  {
     area= a*b;
  }

 };

int main()
{
   Rectangle a;
   Rectangle b(10,20);
   cout<<"Line size is "<<a.point<<endl;
   cout<<"Area is "<<b.area<<endl;
   
   return 0;
}