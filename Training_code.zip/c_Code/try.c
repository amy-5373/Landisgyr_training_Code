#include<stdio.h>
int mqain
