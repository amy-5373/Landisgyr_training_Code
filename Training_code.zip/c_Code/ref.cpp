#include<iostream>
using namespace std;
//  int main()
//  {
//     int i;
//     int & r=i;

 
//     i=9;
//     printf(" printing i and r normally :\n");
//     cout<< i <<"  "<<r<<endl;

//     printf(" printing i and  decremented r: \n ");
//      r--;
//       cout<< i <<"  "<<r<<endl;
//     printf("Printing i and  decremented p (simple assigment): \n");
//      i=9;
//     int p = i;
//     p--;
//       cout<< i <<"  "<<p<<endl;
//       return 0;

//  }
//   int by_value(int age)
//   {
//     return age;
//   }
//   int by_ref(int &age)
//   {
//     age+= 5;
//     return age;
//   }

// int main()
// {
//     int age =95;
//     cout<< by_value(age)<<endl;
//     cout<< by_ref(age)<< " "<<age<<endl;
//     //cout<<age<<endl;
//     return 0;

// }

// void swap(int &a,int &b)
// {
//     int temp;
//     temp=a;
//     a=b;
//     b=temp;
//     cout<<a<<" "<<b<<endl;
// }
void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
    cout<<*a<<" "<<*b<<endl;
    
}

int main()
{
    int a,b;
    a=20;b=30;
   swap(&a,&b); 
    //swap(&a,&b); 
    cout<<a<<" "<<b;
    return 0;

}


 