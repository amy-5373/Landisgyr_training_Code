#include<stdio.h>
#include<stdlib.h>

struct Node *head=NULL;
struct Node *head2=NULL;
struct Node
{
    int data;
     struct Node* next;
};
void print_linkedlist( struct Node* start)
{
    while(start!=NULL)
    {
        printf("%d\n",start->data);
        start=start->next;
    }
}
struct  Node * concatenate(struct Node* head,struct Node* head2)
{
    struct Node* curr1=head;
    while(curr1->next!=NULL)
    {
        curr1=curr1->next;
    }
    curr1->next=head2;
    return head;
}
int main()
{
struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
  struct Node * temp2= (struct  Node*)malloc(sizeof(struct Node));
  struct Node * temp3= (struct Node*)malloc(sizeof(struct Node));
  head=temp1;
  temp1->data= 10;
  temp2->data= 20;
  temp3->data= 30;
  temp1->next=temp2;
  temp2->next=temp3;
  temp3->next=NULL;


struct Node * tem1= (struct Node*)malloc(sizeof(struct Node));
  struct Node * tem2= (struct  Node*)malloc(sizeof(struct Node));
  struct Node * tem3= (struct Node*)malloc(sizeof(struct Node));
  head2=tem1;
  tem1->data= 11;
  tem2->data= 22;
  tem3->data= 33;
  tem1->next=tem2;
  tem2->next=tem3;
  tem3->next=NULL;
  

  print_linkedlist(head);
  printf("\n");
  print_linkedlist(head2);
  printf("\n");
  struct Node *res = concatenate(head,head2);
  print_linkedlist(res);


return 0;
}