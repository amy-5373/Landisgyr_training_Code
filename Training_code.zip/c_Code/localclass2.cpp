#include<iostream>
using namespace std;
  void f(){
    class local{
       
        int f1();// error ,local class cannot use no inline function
        int g(){return 0;} //valid ,inline member(whose definition is with it)

       // static int a;// error, static is not allowed in local class

        int b;//fine 
    };
    local::f1(){
        cout<<"hello"<<endl;
    }
  }
  int main()
  {
    return 0;
  }