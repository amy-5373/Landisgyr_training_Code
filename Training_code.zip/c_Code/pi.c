#include<stdio.h>
#define pi 3.14

int main()
{
printf("%f",pi);
return 0;

