#include<stdio.h>
#include<stdlib.h>

struct Node *temp=NULL;
struct Node *front=NULL;
struct Node *rear=NULL;
//struct Node *rear=NULL;
//struct Node *head2=NULL;
struct Node
{
    int data;
     struct Node* next;
};
void initialize()
{
    front=NULL;
    rear=NULL;
}
int isempty()
{
    if(front==NULL&&front==rear)
        return 1;
        
        return 0;
}
void insert(int x){
temp=(struct Node *)malloc(sizeof(struct Node));
if (temp==NULL)
{
    printf("memory not availabbe\n");
    return;
}
temp->data=x;
temp->next=NULL;
if(front==NULL)
front=temp;
else
rear->next=temp;

rear=temp;

}
void print()
{
    struct Node * curr= (struct Node*)malloc(sizeof(struct Node));
    curr=front;
    while(curr!=NULL)
    {
        printf("%d\t",curr->data);
        curr=curr->next;
    }
}
int peek()
{
    if(isempty())
    {
        printf("queue underflow\n");
        exit(1);
    }
    return front->data;
    
}
void delete()
{
    if(isempty())
    {
        printf("queue underflow\n");
        exit(1);
    }
     struct Node * curr= (struct Node*)malloc(sizeof(struct Node));
    curr=front;
    front=front->next;
    free(curr);
}
int main()
{


  struct Node * front= (struct Node*)malloc(sizeof(struct Node));
  struct Node * rear= (struct Node*)malloc(sizeof(struct Node));
  initialize();
  insert(10);
  insert(20);
  insert(30);
  print();
  printf("%d\n",isempty());
   printf("%d\n",peek());
   delete();
print();

  


}