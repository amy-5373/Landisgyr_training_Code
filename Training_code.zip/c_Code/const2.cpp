#include<iostream>
# define E 3
using namespace std;


class Test{
    int m,n;
    public:
    Test(){

    }
    // parameterized
    Test (int a,int b)
    {
         m=a;
        n=b;
    }

    void print()
    {
        cout<<m<<" "<<n<<endl;
    }
};
 int main()
 {
    // Test* arr=new Test[E];
    Test ob[3];

    for(int j=0;j<E;j++){
        ob[j]=Test(j,j+1);
    }
    for(int j=0;j<E;j++)
    {
        ob[j].print();
    }
    return 0;
 }