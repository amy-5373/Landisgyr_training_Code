#include<iostream>
#include<bits/stdc++.h>

using namespace std;
int main()
{
    int a;
    char str[80];
    cin>>a;
    cin.sync();
    cin.getline(str,80);
    
    // get input from user-
    // BBBBBBBBBBBB fro example
    
    //prints 4
    cout<<a<<endl;
    // printitng string-this
    // will print string now
    cout<<str<<endl;
    return 0;
}
