#include<iostream>
using namespace std;


 class Rectangle{
    private:
    int l=10,b;
    Rectangle(){
        
        b=30;
        //cout<<"heloo"<<endl;
    }
    
    public:
    void display()
    {
        cout<<"\n length -->"<<l<<"\n breadth---> "<<b<<endl;
    }
     static Rectangle fun()  //singleton concept
    {
        static Rectangle a;
        a.l++;
        //a.display();
        //cout<< "hello   "<<endl;
        return a;
    }
 };
int main()
{
//   Rectangle a;
// Rectangle::fun();

Rectangle r= Rectangle::fun();
r.display();

Rectangle r1= Rectangle::fun();
r1.display();
  return 0;
}