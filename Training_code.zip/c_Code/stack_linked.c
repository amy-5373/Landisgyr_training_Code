#include<stdio.h>
#include<stdlib.h>

struct Node *temp=NULL;
struct Node *front=NULL;
struct Node *rear=NULL;
//struct Node *rear=NULL;
//struct Node *head2=NULL;
struct Node
{
    int data;
    struct Node* next;
}*top=NULL;
int isempty()
{
    if(top==NULL){
        //printf("top");
    return 1;
    }
    else
    return 0;
}
int pop()
{
    struct Node *temp;
    int x;
    // if(top!=NULL)
    // printf("NULL");
    if(isempty())
    {
        printf("stack Underflow\n");
        exit(1);
    }
    temp=top;
    x=temp->data;
    top=top->next;
    free(temp);
    return x;
}
void push(int x)
{
     struct Node *temp;
     temp= (struct Node*)malloc(sizeof(struct Node));
    //  if(temp==NULL)
    //  {
    //     printf("No memory: Stack overflow\n");
    //     return;
    //  }
    
     temp->data=x;
     temp->next=NULL;
     if(top)
     temp->next=top;
     
    

    top=temp;

}
void print()
{
    struct Node *topt;
    topt=top;
    while(topt!=NULL)
    {
        printf("%d\t",topt->data);
        topt=topt->next;
    }
}
int main()
{
  push(10);
  push(20);
  push(30);
  push(40);
 
//   printf("%d\n",isempty());

   print();
  printf("\n");

   int x =pop();
   printf("%d\n",x);
  print();
  printf("\n%d",isempty());
  return 0;
}