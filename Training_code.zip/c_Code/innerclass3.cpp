#include<iostream>
#include<string>
using namespace std;
class A{
    public:
    class B{
        public:
        virtual void display()
    {
        cout<<" base display called!"<<endl;
    }
    };
    // B *z;
    
    class C:public B{
        // private:
        // B y;
        public:
        void display()
        {
            cout<<" C display called! "<<endl;
        }
        //A::B y2;
         C *x;
        //A::C*x2;

    };
};

int main()
{
   A::B *ab= new A::C();
   ab->display();
}