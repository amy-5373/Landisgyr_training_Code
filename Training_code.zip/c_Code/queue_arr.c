#include<stdio.h>

int front;
int rear;
int arr[30]={1,2,3};
void insert(int a)
{
    // if(front==-1||rear==-1)
    // {
    //     rear++;
    //     front++;
    //     arr[rear]=a;
    // }
    // else{
        rear++;
        arr[rear]=a;

    // }
}
void print()
{
    for(int i=0;i<3;i++)
    {
        printf("%d\t",arr[i]);
    }
}
int main()
{
    front=-1;rear=-1;

    
    insert(5);
    print();
}
