#include<stdio.h>
#include<stdlib.h>

struct Node *head=NULL;
struct Node
{
    int data;
     struct Node* next;
};
void print_linkedlist( struct Node* start)
{
    while(start!=NULL)
    {
        printf("%d\n",start->data);
        start=start->next;
    }
}
struct Node* reverse(struct Node* start)
{
    struct Node* prev=NULL;
    struct Node* next1=NULL;
    struct Node* curr=start;
    while(curr!=NULL)
    {
    next1= curr->next;
    
    curr->next=prev;
    
    prev= curr;
    curr= next1;
   // next1= next1->next;
    }
    return prev;



}
int main()
{
    
    
  struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
  struct Node * temp2= (struct  Node*)malloc(sizeof(struct Node));
  struct Node * temp3= (struct Node*)malloc(sizeof(struct Node));
  head=temp1;
  temp1->data= 10;
  temp2->data= 20;
  temp3->data= 30;
  temp1->next=temp2;
  temp2->next=temp3;
  temp3->next=NULL;

  

  print_linkedlist(head);
  printf("reversed list is:\n");
  struct Node *reversed =reverse(head);
   print_linkedlist(reversed);
  return 0;
}