#include<iostream>
// #include<bits/stdc++.h>
#include<vector>

using namespace std;

int main()
{
    vector<int>a;
    for(int i=0;i<4;i++)
    a.push_back(i);


    cout<<a.size()<<endl;
    cout<<a.capacity()<<endl;
     cout<<a.max_size()<<endl;
      cout<<a.front()<<endl;
       cout<<a.back()<<endl;
       if(a.empty()==false)
       
        cout<<"NOt empty"<<endl;
        else
        cout<<"  empty"<<endl;
       
    return 0;



}