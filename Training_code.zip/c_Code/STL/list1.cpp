#include<iostream>
#include<list>
#include<iterator>

using namespace std;
void print(list<int>lst){
    list<int>::iterator it;
    for(it=lst.begin();it!=lst.end();++it)
    cout<<*it<<" ";
    cout<<endl;
}
int main()
{
  list<int>list1,list2;
  for(int i=0;i<5;i++)
  {
    list1.push_back(i);
     list2.push_front(i+5);
  }
  cout<<"\nList1 (list1)is: ";
  print(list1);
   cout<<"\nList2 (list2)is: ";
  print(list2);
  cout<<" List1 front "<<list1.front()<<endl;
    cout<<" List1 back "<<list1.back()<<endl;
    cout<<"\nList1.pop_front():";
    list1.pop_front();
    print(list1);

    cout<<"\nList2.pop_front():";
    list2.pop_front();
    print(list2);
  return 0;

}