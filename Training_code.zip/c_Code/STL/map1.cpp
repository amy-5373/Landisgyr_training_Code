#include <iostream>
// #include <set>
#include<map>
using namespace std;
// int main()
// {
//     map<int,string>sapmle_map;
//     sapmle_map.insert(pair<int,string>(1,"one"));
//     sapmle_map.insert(pair<int,string>(2,"two"));
//     cout<< sapmle_map[1]<<" "<< sapmle_map[2]<<endl;
//     return 0;

// }

int main()
{
    map<int,map<int,string>>nested_mp;
    nested_mp[1][1]="one";
    cout<<nested_mp[1][1]<<endl;
    return 0;
}
