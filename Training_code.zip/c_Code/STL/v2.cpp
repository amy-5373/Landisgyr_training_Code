#include<iostream>
// #include<bits/stdc++.h>
#include<vector>

using namespace std;
int main()
{
    vector<int>a;
    for(int i=1;i<=10;i++)
    {
        a.push_back(i*10);

    }
    cout<<"\n Reference operator[g]:a[2]="<<a[2]<<endl;
    cout<<"\nat: at(4)"<<a.at(4)<<endl;
    cout<<a.front()<<endl;
    cout<<a.back()<<endl;

    int *pos=a.data();
    cout<<"\nfirst element is"<<*pos;
    return 0;
}