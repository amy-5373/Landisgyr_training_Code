#include <iostream>
#include <iterator>
#include<set>
// #include <list> // for std::list elements
using namespace std;
int main()
{
    set<string>str_set{"iphone","android","basic"};
    set<char>chr_set{'a','b','c'};
    set<int>int_set{1,2,3,4};

    for(int i=0;i<4;i++)
    int_set.insert('a'+i);
    cout<<*int_set.begin()<<endl;

    cout<<"string set size:"<<str_set.size();
    cout<<endl;
    cout<<"char set size:"<<chr_set.size();
    return 0;
}