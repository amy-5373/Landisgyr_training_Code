#include<iostream>
using namespace std;
int add( int a,int b)
{
    return a+b;
}

double add( double a, double b)
{
    return a+b;
}

 int main()
 {
   int  a,b;
   
   cin>>a>>b;
   cout<< "sum of a and b is "<<add(a,b);
    cout<< "sum of a and b is "<<add(3.2,4.5);
 }