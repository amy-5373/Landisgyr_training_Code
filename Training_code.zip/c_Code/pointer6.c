#include<stdio.h>



int main()
{
    
char *str;
{
    char a='A';
    str= &a;
}
//str is now dangling pointer, pointer pointing to a deallocated memory block.
printf("%c",*str);
return 0;
}