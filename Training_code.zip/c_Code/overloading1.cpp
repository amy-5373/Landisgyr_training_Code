#include<iostream>
using namespace std;

// void display(int a)
// {
//     cout<<a<<endl;
// }
// void display(int a, int b)
// {
//     cout<< a<<" "<<b<<endl;
// }
// int main()
// {
//     display(5);
//     display(6,7);
//     return 0;
// }

// example 2---->
// void func(float){
//     cout<<"Data Type: float\n";

// }
// void func(int){
//     cout<<"data Type: int\n";
// }

// int main()
// {
//     // error func(1.0)
//     func(1.0f);
//     func(1);

//     // float argument
//     func(1.0f);
//     func(1);

//     return 0;
// }


// example 3--->

// int multiply(int a,int b)
// {
//     cout<<"a*b:  "<<a*b<<endl;
//     return a*b;
// }
// double multiply(double a,double b)
// {
//     cout<<"a*b:  "<<a*b<<endl;
//     return a*b;
// }
// void multiply(double a,int b)
// {
//     cout<<"a*b:  "<<a*b<<endl;
//     // return a*b;
// }
// int main()
// {
//     multiply(2,3);
//     multiply(2.0,3.0);
//     multiply(2.0,3);


// }

// example 4---->
// int add(int a){
//     int b=10;
//     return a+b;
// }
int add(int a, int b =10)
{
    return a+b;
    
}
int main()
{
    int a=5;
    // error
    //  cout<<"a+b= "<<add(a)<<endl;
}