#include<iostream>
#include<fstream>
#include<vector>
using namespace std;
int  arr1[2]={1,2};
int arr2[2]={3,4};


void writedb(){

    ofstream out;
    out.open("harry.txt");
    // for(int i=0;i<2;i++){
    out<<arr1[0]<<"\n"<<arr2[0]<<endl;
    out<<arr1[1]<<"\n"<<arr2[1];
    // }
    out.close();
        // harry<<headt->accountnumber<<","<<headt->name<<","<<headt->password<<","<<headt->balance<<","<<headt->account
        // harry.close();

}
    // void readdb(){

    //     ifstream harryin;

    //     string a[20];

    //     string storage;

    //     harryin.open("harrydb.txt");

    //     while(harryin.eof()==0){

    //         getline(harryin,st);

  void readdb()
  {
    ifstream in;
    int arr3[2];
    int arr4[2];
    in.open("harry.txt");
    while(in.eof()==0)
    {
    for(int i=0;i<2;i++){
    in>>arr3[i];
    // in>>arr4[i];
    cout<<arr3[i]<<endl;
    }
    for(int i=0;i<2;i++){
    in>>arr3[i];
    // in>>arr4[i];
    cout<<arr3[i]<<endl;
    }
    in.close();
  }           
  }
 int main()
 {
//     string name[20];
//     string passcode[30];
//     for(int i=0;i<2;i++)
//     {
//         cin>>name[i];
//         cin>>passcode[i];
//     }
//     ofstream out;
//     out.open("harry.txt");
//     out<<" this is blaaa"<<endl;
//     out.close();

//     ofstream out1;
//     out1.open("harry.txt",ios::app);
//     out1<<" \n Bye Bye"<<endl;
//     out1.close();
//     for(int i=0;i<2;i++)
//     {
//     ofstream out3;
//     out3.open("harry.txt",ios::app);
//     out3<< name[i]<<","<<passcode[i]<<endl;
//     out3.close();
//     }

//    string st1,st2;
//    vector<string>v1;
//    vector<float>v2;
readdb();
writedb();

    


    return 0;

 }