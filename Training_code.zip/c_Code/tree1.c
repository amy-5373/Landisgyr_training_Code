#include<stdio.h>
#include<stdlib.h>


struct Node 
{
    int data;
    struct Node * left;
    struct Node * right;
};
 struct Node * createnode(int val){
    struct Node * root= (struct Node*)malloc(sizeof(struct Node));
    root->data=val;
    root->left=NULL;
    root->right=NULL;
    return root;
 }

   struct Node * insertLeft(struct Node *root,int val)
  {
     
     root->left=createnode(val);
     return root->left;
  }


   struct Node * insertRight(struct Node *root,int val)
  {
     
     root->right=createnode(val);
     return root->right;
  }

 void preorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        printf("%d\t", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);

    }
            
 }

  void inorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        inorderTraversal(root->left);
        printf("%d\t", root->data);
       
        inorderTraversal(root->right);

    }
            
 }
   void postorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        postorderTraversal(root->left);
       
       
        postorderTraversal(root->right);
         printf("%d\t", root->data);

    }
            
 }


int main()
{
    struct Node * root= createnode(1);
    insertLeft(root,2);
    insertRight(root,3);
     insertLeft(root->left,4);

     printf("Preorder Traversal \n");
    preorderTraversal(root);
    printf("\n");
    printf("Inorder Traversal \n");
    inorderTraversal(root);
    printf("\n");
    printf("Postorder Traversal \n");
    postorderTraversal(root);
    printf("\n");
    return 0;


}