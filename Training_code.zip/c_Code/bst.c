#include<stdio.h>
#include<stdlib.h>


struct Node 
{
    int data;
    struct Node * left;
    struct Node * right;
};
 struct Node * createnode(int val){
    struct Node * root= (struct Node*)malloc(sizeof(struct Node));
    root->data=val;
    root->left=NULL;
    root->right=NULL;
    return root;
}

struct Node * getsuccessor(struct Node *curr)
{
    curr=curr->right;
    while(curr!=NULL && curr->left!=NULL)
    curr=curr->left;

    return curr;
}
struct Node *insert(struct Node* root,int val)
{
 if(root==NULL) return createnode(val);
    if (val< root->data)
    {
        root->left=insert(root->left,val);
    }
    else
    root->right=insert(root->right,val);
}
struct Node * deletenode(struct Node *root,int key)
{
    if(root==NULL)return root;
    if(key<root->data)
    root->left=deletenode(root->left,key);

    else if(key>root->data)
    root->right=deletenode(root->right,key);

    else{
        if(root->left==NULL)
        {
            struct Node *temp =root->right;
            free(root);
            return temp;
        }
        else if(root->right==NULL)
        {
             struct Node *temp =root->left;
            free(root);
            return temp;
        }
        else
        {
            struct Node *temp1 =getsuccessor(root);
            root->data=temp1->data;
            root->right=deletenode(root->right,temp1->data);
            free(root);
            
        }
        return root;

    }

}

void preorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        printf("%d\t", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);

    }
            
 }

  void inorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        inorderTraversal(root->left);
        printf("%d\t", root->data);
       
        inorderTraversal(root->right);

    }
            
 }
   void postorderTraversal(struct Node *root)
 {
    if(root!=NULL)
    {
        postorderTraversal(root->left);
       
       
        postorderTraversal(root->right);
        printf("%d\t", root->data);

    }
            
 }

int main()
{
    struct Node * root= createnode(20);
    insert(root,10);
    insert(root,24);
    insert(root->left,1);
    insert(root->left,12);
    insert(root->right,15);
    insert(root->right,26);

    printf("Preorder Traversal \n");
    preorderTraversal(root);
    printf("\n");
    struct Node * new = deletenode(root,12);
    printf("%d",new->data);
    printf("Inorder Traversal \n");
    inorderTraversal(root);
    printf("\n");
    printf("Postorder Traversal \n");
    postorderTraversal(root);
    printf("\n");
    return 0;
}
// delete node