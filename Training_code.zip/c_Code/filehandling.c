#include<stdio.h>
int main()
{
    FILE *fp;
    char buff[225];
    fp=fopen("/home/madhu/cpp/text2.txt","r");
    fscanf(fp,"%s",buff);
    printf("1:%s\n",buff);
    fgets(buff,225,(FILE*)fp);
    printf("2: %s",buff);
    fclose(fp);
    
    return 0;
}
