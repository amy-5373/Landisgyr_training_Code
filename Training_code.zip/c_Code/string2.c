#include<stdio.h>
#include<string.h>
// void displayString(char str[])
// {
//     printf("string Output: ");
//     puts(str);
// }

int main()
{
    // //Example 4--->
    // char str[50];
    // printf("Enter string: ");
    // fgets(str,sizeof(str),stdin);
    // displayString(str);


    // //Example 5---->
    // char name[]="Harry Potter";
    // printf("%c", *name); // H
    
    //  printf("%c", *(name+1));// a
    //  printf("%c", *(name+7));//o


    //  char * namePtr;
    //  namePtr=name;
    //  printf("%c", *namePtr); // H
    
    //  printf("%c", *(namePtr+1));// a
    //  printf("%c", *(namePtr+7));//o

    //   //Example 6---->
    //   printf("example 6\n");
    //  char str1[30]="this is";
    //  char str2[30]= "Apple";
    //  strcat(str1,str2);
    //  puts(str1);
    //  puts(str2);

     //example 7---->
    //  printf("example 7---->\n");
    //  char str1[30]="ABCD";
    //  char str2[30]="ABCd";
    //  char str3[30]="ABCD";
    //  int result;
    //  result=strcmp(str1,str2);
    //  printf("strcmp(str1,str2)=%d\n",result);// if same output 0

    //  result=strcmp(str1,str3);
    //  printf("strcmp(str1,str3)=%d\n",result);

//Example---->8
printf("example 8---->\n");
char str1[30]="this is Rak, with c and c++";
char *sub;
sub= strstr(str1,"Rak");
printf("\n Substring is : %s",sub);


//Example---->9
printf("example 9---->\n");
char str1[30]="ABCD";
//char str2[30]=;
printf("reverse of the str1 is: %s ",strrev(str1));







      return 0;
}
