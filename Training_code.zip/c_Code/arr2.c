#include<stdio.h>
int main()
{

int arr[2];
printf("%d",arr[3]);
printf("%d",arr[-2]);

return 0;
}
