#include<iostream>
using namespace std;
// int main()
// {
//    int var=0;
//    int c=20;
//      cout<<"hello1"<<endl;
//      int d=c/var;

//    cout<<d<<endl;
//    cout<<"hello"<<endl;
//    return 0;
// }


// exampe ----2
int main()
{
    float var=0;
   int c=20;
    //  cout<<"hello1"<<endl;
    //  int d=c/var;
     try{
    //  if(true)
    //  {
    //     cout<<"oooo"<<endl;
    //     throw var;
    //     // int d=c/var;
    //     cout<<"hiiii";
    //  }
    throw var;
     }
     catch(float ex)
     {
        cout<<" hEy!"<<endl;
     }
     catch(...)
     {
        cout<<"default catch"<<endl;
     }
     return 0;
}