#include <iostream>
using namespace std;
// class complx
// {
// public:
//     double real, imag;
//     complx(double real = 0., double imag = 0.);
//     complx operator+(const complx &) const;
// };
// complx::complx(double r, double i)
// {
//     real = r;
//     imag = i;
// //     cout << "real=" << real << "imag=" << imag << endl;
// // }
// complx complx::operator+(const complx &c) const
// {
//     complx result;
//     result.real = (this->real + c.real);
//     result.imag = (this->imag + c.imag);
//     return result;
// }
// int main()
// {
//     complx x(4, 4);
//     complx y(4, 4);
//     complx z = x + y;
//     cout << "z.real=" << z.real << " z.imag=" << z.imag;
//     return 0;
// }
class overload{
private:
int a;
int b;
public:
overload(): a(0),b(0){}
void in(){
    cout<<"Enter a"<<endl;
    cin>>a;
    cout<<"Enter b"<<endl;
    cin>>b;
}
void operator--()
{
    a=--a;
    b=--b;
}
void out(){

    cout<<"Decement element of objects"<<a<<" "<<b<<endl;
}
};
int main()
{
    overload obj;
    obj.in();
    --obj;
    obj.out();
    return 0;
}

