#include<stdio.h>
#include<stdlib.h>

struct Node *head=NULL;
struct Node
{
    int data;
     struct Node* next;
};
void insert_end( int new_ele)
{
    struct Node* new_node= (struct Node*)malloc(sizeof(struct Node));
    new_node->data=new_ele;
 struct Node* temp=head;
    while(temp->next!=NULL)
    {
        
        temp=temp->next;
    }
    temp->next=new_node;
    
    new_node->next=NULL;
}
void print_linkedlist( struct Node* start)
{
    while(start!=NULL)
    {
        printf("%d\n",start->data);
        start=start->next;
    }
}
void delete(int pos)
{
    struct Node* temp=head;
    for(int i=0;i<pos-2;i++)
    {
        temp=temp->next;
    }
    temp->next=temp->next->next;

}

// struct Node *head=NULL;
int main()
{
    
    
  struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
  struct Node * temp2= (struct  Node*)malloc(sizeof(struct Node));
  struct Node * temp3= (struct Node*)malloc(sizeof(struct Node));
  head=temp1;
  temp1->data= 10;
  temp2->data= 20;
  temp3->data= 30;
  temp1->next=temp2;
  temp2->next=temp3;
  temp3->next=NULL;

  

  print_linkedlist(head);
  insert_end(40);
  printf("\n");
  print_linkedlist(head);
  delete(2);
  print_linkedlist(head);

 return 0;

}