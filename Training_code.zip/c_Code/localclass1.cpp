#include<iostream>
using namespace std;
int x=20;
int *p;
void f()
{
    static int y=10;
    p=&y;
    int x;
    extern int g();
    class local
    {
        public:
       // int g(){return x;}//   error, local variable x cannot be used by g
        int h(){return y;}//  valid,static varible
        int k(){return ::x;}//  
        int l(){return g();}
    };
    local p;
    cout<<p.k()<<endl;
}
int main()
{
    f();
    cout<<*p<<endl;
    return 0;
}