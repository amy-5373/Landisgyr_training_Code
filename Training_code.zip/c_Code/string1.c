#include<stdio.h>
#include<string.h>

int main()
{
    //example1
    printf("Example1---->\n");
    char ch1[11]={'a','b','c'};
    char ch2[11]="xyz";

    printf("printing ch1 =%s ",ch1);
    printf("printing ch2 =%s \n",ch2);


    //Example 2
     printf("Example 2--->\n");
     char name1[20];
     printf("Enter name:");
     scanf("%s",name1);
     printf("Your name is %s.",name1);


    //example3
    printf("Example 3---->\n");

    char name[30];
    printf("Enter Name: ");
    fgets(name,sizeof(name),stdin);
    printf("Name: ");
    puts(name);


   

        return 0;

}
