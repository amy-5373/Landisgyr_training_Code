#include<stdio.h>

int main()
{
int a,b;
scanf("%d",&a);
scanf("%d",&b);
printf("Sum of a and b %d", a+b);
return 0;
}
