#include<iostream>
using namespace std;

namespace first
{
    int x=5;
    int y=10;
}
namespace second
{
    double x=3.1416;
    double y= 2.7346;
}
int main()
{
    //cout<<first::value()<<endl;
    using namespace first;
    cout<<x<<endl<<y<<"\n";
    using first::x;
    using second::y;
    cout<<x<<endl<<y<<"\n";
    cout<<first::x<<"\n";
    return 0;
    
}