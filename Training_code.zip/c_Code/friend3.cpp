#include<iostream>
using namespace std;
//forward declaration
class classB;
class classA {
    public:
    // constructor to initialize numA to 12
    classA():numA(12){}

    private:
    int numA=50;
    friend class classB;
};
class classB {
    public:
    // constructor to initialize numA to 12
    classB():numB(12){}

    int add(){
        classA obA;
        return obA.numA+ numB;
    }

    private:
    int numB=40;
    friend class claasB;
};

int main()
{
    classB obB;
    cout<<"sum: "<<obB.add();
    return 0;
}

