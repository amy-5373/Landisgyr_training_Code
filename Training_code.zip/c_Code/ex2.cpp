
#include<iostream>
using namespace std;


// int main()
// {
//     float var=0;
//    int c=20;
//     //  cout<<"hello1"<<endl;
//     //  int d=c/var;
//      try{
        
//      if(var==0)
//      {
//         cout<<"oooo"<<endl;
//         throw var;
//         // int d=c/var;
//         cout<<"hiiii";
//      }
//       cout<<"hiiii2222222222";
  
//      }
//      catch(float ex)
//      {
//         cout<<" hEy!"<<endl;
//      }
//      catch(...)
//      {
//         cout<<"default catch"<<endl;
//      }
//      return 0;
// }



// example------>
// void test(int x)
// {
//     try{
//         if(x>0)
//         throw x;
//         else
//         throw 'x';

//     }
//     catch(int x){
//         cout<<" Catch a integer"<<endl;
//     }
//     catch(char x){
//         cout<<" catch a char"<<endl;
//     }
// }
// int main()
// {  char a= 'a';
// int d= 2;
// test(a);
// test(0);
// return 0;

// }


// example---

// void exceptionFunction(){
//     try{
//         throw 0;
//     }

//         catch(int i){
//             cout<<"\n IN function: wrong input"<<i;
//             throw;
//         }
    
// }
//  int main()
// {
//    int var=0;
// //    int c=20;
// //      cout<<"hello1"<<endl;
// //      int d=c/var;
//      try{
          
//           exceptionFunction();
//         }
//      catch(int ex){
//         cout<<"\n\n Main:  wrong input"<<ex;
//      }
  
// //    cout<<d<<endl;
// //    cout<<"hello"<<endl;
//    return 0;
// }


// example----

// struct MyException: public exception{
//     const char * what()const throw(){
//         return "C++ Exception";
//     }
// };
// int main()
// {
//     try
//     {
//         throw MyException();
//     }
//     catch( MyException& e){
//        std::cout<<"My Exception cought"<<std::endl;
//        std::cout<<e.what()<<std::endl;
//     }
//     catch(std::exception & e){
//         // other error
//     }

// }


// 
