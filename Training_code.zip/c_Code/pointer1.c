#include<stdio.h>
#include<stdlib.h>

int addition ()
{
    int a,b;
    printf("enter two number:");
    scanf("%d %d",&a,&b);
    return a+b;
}
int sum(){
    return 20+30;
}
int fun1 (int a)
{
    return a;
}


int main()
{
//     int x=10;
//     printf("address of x: %p", &x);
//

//example 2---->
// int *pc,c;
// c=22;
// printf("Address of c: %p\n",&c);
// printf("Address of c: %d\n\n",c);

// pc=&c;
// printf("Address of c: %p\n",pc);
// printf("Address of c: %d\n\n",*pc);


// c=11;
// printf("Address of c: %p\n",pc);
// printf("Address of c: %d\n\n",*pc);

// *pc=2;
// printf("Address of c: %p\n",&c);
// printf("Address of c: %d\n\n",*pc);


// example 3---->

// int *ptr=NULL;
// printf("the value of ptr is :%x",ptr);//




// // example--->4
// int *ptr=(int *)malloc(sizeof(int));
// int a = 560;
// ptr = &a;
// free(ptr);
// ptr=NULL;


// example 6-->
// char *str;
// {
//     char a='A';
//     str= &a;
// }
// str is now dangling pointer, pointer pointing to a deallocated memory block.
// printf("%c",*str);
// example 7-->

// Dangling example
// making y static stores in global storage ,hence not dangling for static
// int * fun()
// {
//      static int y =10; // without static it will not print
//     return &y;

// }
// int *p=fun();
// printf("%d",*p);
//

//example ---->11

int result;
int (*ptr)();
 ptr=&addition;
// // ptr=&sum;
// ptr=&fun1;
result=(*ptr)();
printf("the sum is %d",result);












 return 0;

  
// 
}
