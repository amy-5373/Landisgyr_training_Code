#include<iostream>
using namespace std;
int x;
void fun()
{
    class Test1
    {
        public:
      Test1(){
        cout<<"test1:: Test1()"<<endl;
      }
    };
    class Test2
    {
        Test1 t1;//  fine a local class and acess another local class

        public:
        void method(){
        cout<<"x= "<<x<<endl;// fine 
        }
    };

    Test2 t2;
    t2.method();
}

    int  main()
    {
        fun();
        return 0;
    }


