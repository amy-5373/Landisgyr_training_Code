#include<iostream>
using namespace std;
namespace addition{
     int operation (int x,int y){return x+y;}

 }
 namespace variable
 {
  int x=4;
  int y=5;
  //cin>>x>>y; 
   
 }
 int main()
 {  int x; int y;
    cout<<addition::operation(variable::x , variable::y)<<endl;
    return 0;
 }