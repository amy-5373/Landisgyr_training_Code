#include<iostream>
using namespace std;
// forword declaration
class classB;
class classA {
    public:
    // constructor to initialize numA to 12
    classA():numA(12){}

    private:
    int numA=40;
    friend int add(classA, classB);
};
class classB{
    public:
    classB():numB(1){}
    private:
    int numB;
    friend int add(classA, classB);

};
int add(classA obA,classB obB){
    return (obA.numA +  obB.numB);
}
int main()
{
    
    classB obB;
       
    classA obA;
    cout<<"sum: "<<add(obA,obB);
    return 0;
}