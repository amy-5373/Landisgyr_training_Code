#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct Node *head=NULL;
//struct Node *head2=NULL;
struct Node
{
    int data;
     struct Node* next;
};
bool loop(struct Node * head)
{
    struct Node *slow,*fast;
    slow=head;
    fast=head;
    while(slow!=NULL&&fast!= NULL && fast->next!=NULL)
    {
        slow=slow->next;
        fast=fast->next->next;
        if(slow==fast)
        return true;
    }
    return false;
}
// void print_linkedlist( struct Node* start)
// {
//     while(start!=NULL)
//     {
//         printf("%d\n",start->data);
//         start=start->next;
//     }
// }
int main()
{
struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
  struct Node * temp2= (struct  Node*)malloc(sizeof(struct Node));
  struct Node * temp3= (struct Node*)malloc(sizeof(struct Node));
  struct Node * temp4= (struct Node*)malloc(sizeof(struct Node));
  head=temp1;
  temp1->data= 10;
  temp2->data= 20;
  temp3->data= 30;
   temp4->data= 40;
  temp1->next=temp2;
  temp2->next=temp3;
  temp3->next=temp4;
  temp4->next=temp2;


  bool res= loop(head);
  if(res==true)
  printf("loop exist\n");
  else
  printf("loop  does not exist\n");
  return 0;
}