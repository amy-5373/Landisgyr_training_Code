#include<iostream>
using namespace std;

class A{
    public:
    int n,m;
    A(): n(10),m(30){}/// just method of initialising variable of class.
};

int main()
{
  A a;
  cout<<a.n<<" "<<a.m<<endl;
}