#include<stdio.h>
#include<stdlib.h>

struct Node *head=NULL;
//struct Node *head2=NULL;
struct Node
{
    int data;
     struct Node* next;
};
void print_linkedlist( struct Node* start)
{
    while(start!=NULL)
    {
        printf("%d\n",start->data);
        start=start->next;
    }
}
struct Node *sort_list(struct Node* head,int info)
{
    struct Node *p;
    struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
    temp1->data=info;

    if(head==NULL||info<head->data)
    {
        temp1->next=head;
        head=temp1;
        return head;
    }
    p=head;
    while(p->next!=NULL&& p->next->data<=info)
    {
        p=p->next;
    }
    temp1->next=p->next;
    p->next=temp1;
    return head;

}
int main()
{
  head= sort_list(head,4);
  head= sort_list(head,1);
  head= sort_list(head,2);
  head= sort_list(head,5);
  print_linkedlist(head);
  
  //sort_list(head);
return 0;
}