#include<iostream>
#include<string>

using namespace std;
class Poingable{
    public:
    virtual void poing()=0;
};
void callPoing(Poingable& p)
{
    p.poing();
}
class Bingable{
    public:
    virtual void bing()=0;
};
void callBing(Bingable& b)
{
    b.bing();
}

class outer {
    string name;
    class inner1;
    friend class outer::inner1;
    class inner1:public Poingable{
        outer *parent;
        public:
        inner1(outer *p): parent(p){}
        void poing(){
            cout<<"poing called for"<<parent->name<<endl;

        }
    }inner1;
    class inner2;
    friend class outer::inner2;
    class inner2: public Bingable{
        outer *parent;
        public:
        inner2(outer *p): parent(p){}
        void bing(){
            cout<<"bing called for"<<parent->name<<endl;

        }
    }inner2;
    public:
    outer(const string &nm)
    : name(nm),inner1(this), inner2(this){}
//return reference to 
// Implemented by inner classes
    operator Poingable&(){return inner1;}
    operator Bingable&(){return inner2;}

};

int main()
{
 outer x("Ping Pong");
//Like upcasting to multiple base types!:
 callPoing(x);
 callBing(x);
}