#include<stdio.h>


int * fun()
{
     static int y =10; // without static it will not print
    return &y;

}
int main()
{
    //Dangling example
// making y static stores in global storage ,hence not dangling for static
// 
int *p=fun();
printf("%d",*p);
return 0;
}