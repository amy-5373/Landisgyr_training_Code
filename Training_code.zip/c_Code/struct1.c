#include<stdio.h>
struct Point
{
int x,y;
};


int main()
{
struct Point P1={1,2};
struct Point*P2= &P1;
printf("%d %d",P2->x,P2->y);
return 0;
}

