#include<iostream>
using namespace std;


 class Myclass{
    public:
    int mynum;
    string mystring;
    Myclass(){
     mynum=20;
     mystring="some";
    }
   
 };
 int main()
 {
   Myclass myobj;
//    myobj.num=15;
//    myobj.mystring= "some text";
   cout<<myobj.mynum<<endl;
   cout<<myobj.mystring<<endl;
    return 0;
 }