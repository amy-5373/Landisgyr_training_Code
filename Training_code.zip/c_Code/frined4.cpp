
#include<iostream>
using namespace std;



// child class will not access the parents friend class.
class A{
    friend classs B;
    int a;

};
class B{}
class C:public B{
    void f(A*p){
    // following is error
    p->a=2;
    }
};
int main(){
    


    return 0;
}