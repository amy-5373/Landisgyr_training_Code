#include<stdio.h>
struct structjob
{
 char name[32];
 float salary;
 int worknn;
 
 
 }sjob;
 
union unionjob
 {
 char name[32];
 float salary;
 int worknn;
 
 
 }ujob;
  int main()
  {
  printf("size of union =%lu bytes",sizeof(ujob));
  printf("size of struct =%lu bytes",sizeof(sjob));
  return 0;
  }


