#include<stdio.h>
#include<stdlib.h>

struct Node * head=NULL;

//struct Node *head=NULL;
struct Node
{
    int data;
     struct Node* next;
      struct Node* prev;
};
void insert_end( int new_ele)
{
    struct Node* new_node= (struct Node*)malloc(sizeof(struct Node));
    new_node->data=new_ele;
 struct Node* temp=head;
    while(temp->next!=NULL)
    {
        
        temp=temp->next;
    }
    temp->next=new_node;
    new_node->prev=temp;
    new_node->next=NULL;
}
void delete_node(int ele)
{
    struct Node *temp;
    struct Node * curr=head;
    while(curr!=NULL)
    {
        if(curr->data==ele)
        {
            temp=curr->prev;
            temp->next=curr->next;
            curr->next->prev=temp;
            free(temp);
        }
        curr=curr->next;
    }
}
void print_linkedlist( struct Node* start)
{
    while(start!=NULL)
    {
        printf("%d\n",start->data);
        start=start->next;
    }
}
int main()
{
    struct Node * temp1= (struct Node*)malloc(sizeof(struct Node));
    temp1->data= 10;
    temp1->next=NULL;
    temp1->prev=NULL;
    head=temp1;
    insert_end(20);
    insert_end(30);
    delete_node(20);
     print_linkedlist(head);
     return 0;


}